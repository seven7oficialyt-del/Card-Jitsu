import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_state.dart';
import 'screens/menu_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations(
      [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  final state = AppState();
  await state.init();
  runApp(AppScope(state: state, child: const CardJitsuApp()));
}

class CardJitsuApp extends StatelessWidget {
  const CardJitsuApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Card-Jitsu',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(fontFamily: 'Salsa', useMaterial3: true, colorSchemeSeed: const Color(0xFF1B6FD1)),
        home: const MenuScreen(),
      );
}
