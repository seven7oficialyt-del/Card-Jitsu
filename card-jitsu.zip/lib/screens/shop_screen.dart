import 'package:flutter/material.dart';
import '../app_state.dart';
import '../widgets.dart';

class ShopScreen extends StatelessWidget {
  const ShopScreen({super.key});

  Future<void> _buy(BuildContext context, AppState app) async {
    final n = packCardsPerElement * 3;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        content: Text(app.t('ensure_buy', p: {'number': n, 'price': packPrice})),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(app.t('cancel'))),
          TextButton(onPressed: () => Navigator.pop(context, true), child: Text(app.t('buy'))),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    final cards = await app.buyPack();
    if (!context.mounted) return;
    if (cards == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(app.t('not_enough_coins'))));
      return;
    }
    app.sfx('stamp_earned.ogg');
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        content: Wrap(spacing: 6, runSpacing: 6, alignment: WrapAlignment.center,
            children: [for (final c in cards) CardView(card: c, height: 100)]),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text(app.t('ok')))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final n = packCardsPerElement;
    return Scaffold(
      body: Backdrop(
        asset: 'assets/backgrounds/shop_background.jpg',
        child: Column(children: [
          ScreenBar(app.t('shop')),
          Expanded(
            child: Center(
              child: Card(
                color: Colors.black54,
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const AssetImg('assets/icons/cards.png', height: 90, fallback: Icon(Icons.style, size: 80, color: Colors.white)),
                    const SizedBox(width: 20),
                    Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(app.t('cards_pack'), style: const TextStyle(color: Colors.white, fontSize: 24)),
                      Text(app.t('pack_desc', p: {'number': n}), style: const TextStyle(color: Colors.white70)),
                      const SizedBox(height: 10),
                      BigButton('${app.t('buy')}  ·  $packPrice', width: 200, onTap: () => _buy(context, app)),
                    ]),
                  ]),
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
