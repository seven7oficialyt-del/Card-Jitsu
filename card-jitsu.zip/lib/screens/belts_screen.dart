import 'package:flutter/material.dart';
import '../app_state.dart';
import '../widgets.dart';

class BeltsScreen extends StatelessWidget {
  const BeltsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    return Scaffold(
      body: Backdrop(
        asset: 'assets/backgrounds/main_background.jpg',
        child: Column(children: [
          ScreenBar(app.t('belts_guide'), showCoins: false),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 8),
              itemCount: belts.length,
              itemBuilder: (_, i) {
                final (name, need) = belts[i];
                final current = i == app.beltIndex;
                return Card(
                  color: current ? Colors.amber.withOpacity(.85) : Colors.black54,
                  child: ListTile(
                    leading: AssetImg('assets/images/belts/${name}_ninja_belt.png', height: 34),
                    title: Text('${app.t('wins')}: $need', style: TextStyle(color: current ? Colors.black : Colors.white)),
                    trailing: app.wins >= need ? const Icon(Icons.check_circle, color: Colors.greenAccent) : null,
                  ),
                );
              },
            ),
          ),
        ]),
      ),
    );
  }
}
