import 'package:flutter/material.dart';
import '../app_state.dart';
import '../widgets.dart';
import 'belts_screen.dart';
import 'collection_screen.dart';
import 'game_screen.dart';
import 'settings_screen.dart';
import 'shop_screen.dart';

class MenuScreen extends StatelessWidget {
  const MenuScreen({super.key});
  void _go(BuildContext c, Widget w) => Navigator.push(c, MaterialPageRoute(builder: (_) => w));

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    return Scaffold(
      body: Backdrop(
        asset: 'assets/backgrounds/main_background.jpg',
        child: Stack(children: [
          Positioned(top: 8, right: 12, child: const CoinBadge()),
          Positioned(top: 8, left: 12, child: Row(children: [
            AssetImg('assets/images/belts/${app.beltName}_ninja_belt.png', height: 30),
            const SizedBox(width: 8),
            Text('${app.t('wins')}: ${app.wins}', style: const TextStyle(color: Colors.white, fontSize: 16)),
          ])),
          const Positioned(bottom: 6, left: 0, right: 0,
              child: Center(child: Text("© Mino's", style: TextStyle(color: Colors.white70, fontSize: 14, fontFamily: 'Courgette')))),
          Center(
            child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Text('Card-Jitsu', style: const TextStyle(fontFamily: 'Courgette', fontSize: 44, color: Colors.white,
                    shadows: [Shadow(blurRadius: 8, color: Colors.black)])),
                const SizedBox(height: 8),
                BigButton(app.t('play'), onTap: () => _go(context, const GameScreen())),
                Row(mainAxisSize: MainAxisSize.min, children: [
                  BigButton(app.t('collection'), width: 160, onTap: () => _go(context, const CollectionScreen())),
                  const SizedBox(width: 12),
                  BigButton(app.t('shop'), width: 160, onTap: () => _go(context, const ShopScreen())),
                ]),
                Row(mainAxisSize: MainAxisSize.min, children: [
                  BigButton(app.t('belts_guide'), width: 160, onTap: () => _go(context, const BeltsScreen())),
                  const SizedBox(width: 12),
                  BigButton(app.t('settings'), width: 160, onTap: () => _go(context, const SettingsScreen())),
                ]),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}
