import 'dart:math';
import 'package:flutter/material.dart';
import '../app_state.dart';
import '../core/engine.dart';
import '../core/models.dart';
import '../widgets.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});
  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  final _rng = Random();
  late MatchState m;
  CJCard? shownP, shownO;
  RoundResult? last;
  bool busy = false, started = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!started) { started = true; _newMatch(); }
  }

  void _newMatch() {
    final app = AppScope.of(context);
    final opp = ([...app.allCards]..shuffle(_rng)).take(40).toList();
    m = MatchState(_rng, app.ownedCards, opp);
    shownP = shownO = null;
    last = null;
    busy = false;
  }

  Future<void> _play(CJCard card) async {
    if (busy || m.finished) return;
    final app = AppScope.of(context);
    setState(() { busy = true; shownP = card; shownO = aiPick(m, _rng); last = null; });
    await Future.delayed(const Duration(milliseconds: 600));
    if (!mounted) return;
    final r = m.play(card, shownO!);
    app.sfx('effect_${(r.winner == Side.opp ? r.oppElem : r.playerElem).name}.mp3');
    setState(() => last = r);
    await Future.delayed(const Duration(milliseconds: 1600));
    if (!mounted) return;
    if (m.finished) { await _end(app); return; }
    setState(() { shownP = shownO = null; last = null; busy = false; });
  }

  Future<void> _end(AppState app) async {
    final won = m.winner == Side.player;
    final draw = m.winner == null;
    var gain = 0; var newBelt = false;
    if (!draw) { (gain, newBelt) = await app.recordResult(won: won); }
    if (newBelt) app.sfx('stamp_earned.ogg'); else app.sfx('bell_end.mp3');
    if (!mounted) return;
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: Text(draw ? app.t('it_is_draw') : won ? app.t('victory') : app.t('defeat')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          if (!draw) Text('${app.t('coins_earned')}: +$gain'),
          if (newBelt) ...[
            const SizedBox(height: 8),
            AssetImg('assets/images/belts/${app.beltName}_ninja_belt.png', height: 40),
            Text(app.t('new_belt'), textAlign: TextAlign.center),
          ],
        ]),
        actions: [
          TextButton(onPressed: () { Navigator.pop(context); Navigator.pop(context); }, child: Text(app.t('menu'))),
          TextButton(onPressed: () { Navigator.pop(context); setState(_newMatch); }, child: Text(app.t('play_again'))),
        ],
      ),
    );
  }

  Widget _wonRow(List<CJCard> won) => SizedBox(
        height: 28,
        child: ListView(scrollDirection: Axis.horizontal, shrinkWrap: true, children: [
          for (final c in won)
            Container(
              margin: const EdgeInsets.only(right: 4),
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(color: c.color.value, borderRadius: BorderRadius.circular(6), border: Border.all(color: Colors.white, width: 1.5)),
              child: AssetImg(c.element.icon, height: 20),
            ),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final r = last;
    return Scaffold(
      body: Backdrop(
        asset: 'assets/backgrounds/cardjitsu_game_background.jpg',
        child: LayoutBuilder(builder: (_, box) {
          final handH = box.maxHeight * .30;
          final playH = box.maxHeight * .34;
          return Column(children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              child: Row(children: [
                IconButton(icon: const Icon(Icons.close, color: Colors.white), onPressed: () => Navigator.pop(context)),
                Expanded(child: _wonRow(m.oppWon)),
                Text('${app.t('round')} ${m.round + 1}', style: const TextStyle(color: Colors.white, fontSize: 18)),
              ]),
            ),
            Expanded(
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                CardView(card: shownO, height: playH),
                SizedBox(
                  width: 150,
                  child: Text(
                    r == null ? (busy ? '' : app.t('your_turn'))
                        : r.winner == null ? app.t('it_is_draw')
                        : r.winner == Side.player ? '${app.t('you')} ✔' : '${app.t('opponent')} ✔',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white, fontSize: 20, shadows: [Shadow(blurRadius: 6, color: Colors.black)]),
                  ),
                ),
                CardView(card: shownP, height: playH),
              ]),
            ),
            Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: _wonRow(m.playerWon)),
            const SizedBox(height: 4),
            SizedBox(
              height: handH + 8,
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                for (final c in m.playerHand)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: Opacity(opacity: busy ? .5 : 1, child: CardView(card: c, height: handH, onTap: () => _play(c))),
                  ),
              ]),
            ),
          ]);
        }),
      ),
    );
  }
}
