import 'package:flutter/material.dart';
import '../app_state.dart';
import '../widgets.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    return Scaffold(
      body: Backdrop(
        asset: 'assets/backgrounds/main_background.jpg',
        child: Column(children: [
          ScreenBar(app.t('settings'), showCoins: false),
          Expanded(
            child: Center(
              child: Card(
                color: Colors.black54,
                child: SizedBox(
                  width: 420,
                  child: ListView(shrinkWrap: true, padding: const EdgeInsets.all(12), children: [
                    SwitchListTile(
                      title: Text(app.t('sounds'), style: const TextStyle(color: Colors.white)),
                      value: app.sound, onChanged: app.setSound),
                    ListTile(
                      title: Text(app.t('lang'), style: const TextStyle(color: Colors.white)),
                      trailing: DropdownButton<String>(
                        value: app.lang, dropdownColor: Colors.black87, style: const TextStyle(color: Colors.white),
                        items: [for (final l in AppState.langs) DropdownMenuItem(value: l, child: Text(app.t(l)))],
                        onChanged: (v) { if (v != null) app.setLang(v); },
                      ),
                    ),
                    TextButton(
                      onPressed: () async {
                        final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
                          content: Text(app.t('reset_confirm')),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(context, false), child: Text(app.t('cancel'))),
                            TextButton(onPressed: () => Navigator.pop(context, true), child: Text(app.t('ok'))),
                          ]));
                        if (ok == true) await app.resetProgress();
                      },
                      child: Text(app.t('reset_progress'), style: const TextStyle(color: Colors.redAccent)),
                    ),
                    const Divider(color: Colors.white24),
                    const Padding(padding: EdgeInsets.all(4), child: Text("Card-Jitsu · Mino's", style: TextStyle(color: Colors.white, fontSize: 14))),
                    for (final k in ['credit1', 'credit2', 'credit3'])
                      Padding(padding: const EdgeInsets.all(4), child: Text(app.t(k), style: const TextStyle(color: Colors.white54, fontSize: 12))),
                  ]),
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
