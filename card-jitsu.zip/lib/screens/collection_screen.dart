import 'package:flutter/material.dart';
import '../app_state.dart';
import '../core/models.dart';
import '../widgets.dart';

class CollectionScreen extends StatefulWidget {
  const CollectionScreen({super.key});
  @override
  State<CollectionScreen> createState() => _CollectionScreenState();
}

class _CollectionScreenState extends State<CollectionScreen> {
  Elem? filter;
  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final counts = app.ownedCounts.entries.where((e) => filter == null || e.key.element == filter).toList()
      ..sort((a, b) => a.key.id.compareTo(b.key.id));
    return Scaffold(
      body: Backdrop(
        asset: 'assets/backgrounds/shop_background.jpg',
        child: Column(children: [
          ScreenBar('${app.t('collection')} (${app.collection.length})'),
          Wrap(spacing: 8, children: [
            ChoiceChip(label: Text(app.t('all')), selected: filter == null, onSelected: (_) => setState(() => filter = null)),
            for (final e in Elem.values)
              ChoiceChip(
                avatar: AssetImg(e.icon, height: 18),
                label: Text(app.t(e.name)),
                selected: filter == e,
                onSelected: (_) => setState(() => filter = e),
              ),
          ]),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(12),
              gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 120, childAspectRatio: .88, crossAxisSpacing: 8, mainAxisSpacing: 8),
              itemCount: counts.length,
              itemBuilder: (_, i) {
                final e = counts[i];
                return Stack(children: [
                  Positioned.fill(child: CardView(card: e.key, height: 130)),
                  if (e.value > 1)
                    Positioned(right: 0, top: 0, child: CircleAvatar(radius: 11, backgroundColor: Colors.black87,
                        child: Text('${e.value}', style: const TextStyle(color: Colors.white, fontSize: 12)))),
                ]);
              },
            ),
          ),
        ]),
      ),
    );
  }
}
