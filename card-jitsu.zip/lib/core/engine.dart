import 'dart:math';
import 'models.dart';

class RoundResult {
  final Side? winner; // null = empate
  final Elem playerElem, oppElem;
  final int playerRank, oppRank;
  final List<Power> powers;
  final List<CJCard> removed;
  const RoundResult(this.winner, this.playerElem, this.oppElem, this.playerRank,
      this.oppRank, this.powers, this.removed);
}

/// ¿Las cartas ganadas cumplen una condición de victoria?
bool hasWon(List<CJCard> won) {
  // 3 colores distintos del mismo elemento
  for (final e in Elem.values) {
    final colors = won.where((c) => c.element == e).map((c) => c.color).toSet();
    if (colors.length >= 3) return true;
  }
  // 3 elementos distintos con 3 colores distintos
  for (final f in won.where((c) => c.element == Elem.fire)) {
    for (final w in won.where((c) => c.element == Elem.water)) {
      if (w.color == f.color) continue;
      for (final s in won.where((c) => c.element == Elem.snow)) {
        if (s.color != f.color && s.color != w.color) return true;
      }
    }
  }
  return false;
}

class MatchState {
  static const handSize = 5;
  final Random rng;
  final List<CJCard> playerPile, oppPile;
  final List<CJCard> playerHand = [], oppHand = [];
  final List<CJCard> playerWon = [], oppWon = [];
  Side? winner;
  bool finished = false;
  int round = 0;

  MatchState(this.rng, List<CJCard> playerCards, List<CJCard> oppCards)
      : playerPile = List.of(playerCards)..shuffle(rng),
        oppPile = List.of(oppCards)..shuffle(rng) {
    _refill();
  }

  void _refill() {
    while (playerHand.length < handSize && playerPile.isNotEmpty) {
      playerHand.add(playerPile.removeLast());
    }
    while (oppHand.length < handSize && oppPile.isNotEmpty) {
      oppHand.add(oppPile.removeLast());
    }
  }

  RoundResult resolve(CJCard p, CJCard o) {
    var pe = p.element, oe = o.element;
    var pr = p.rank, orr = o.rank;
    final used = <Power>[];

    if (p.power == Power.plus2) { pr += 2; used.add(Power.plus2); }
    if (o.power == Power.plus2) { orr += 2; used.add(Power.plus2); }
    for (final c in [p, o]) {
      if (c.power == Power.changeElement) {
        final t = c.element.converted;
        pe = t; oe = t;
        used.add(Power.changeElement);
      }
    }
    final rev = (p.power == Power.reversal) != (o.power == Power.reversal);
    if (p.power == Power.reversal || o.power == Power.reversal) used.add(Power.reversal);

    Side? w;
    if (pe != oe) {
      w = pe.beats == oe ? Side.player : Side.opp;
    } else if (pr != orr) {
      w = ((pr > orr) != rev) ? Side.player : Side.opp;
    }
    return RoundResult(w, pe, oe, pr, orr, used, const []);
  }

  RoundResult play(CJCard p, CJCard o) {
    playerHand.remove(p);
    oppHand.remove(o);
    var r = resolve(p, o);
    final removed = <CJCard>[];

    if (r.winner != null) {
      final winCard = r.winner == Side.player ? p : o;
      final myWon = r.winner == Side.player ? playerWon : oppWon;
      final theirWon = r.winner == Side.player ? oppWon : playerWon;
      myWon.add(winCard);
      switch (winCard.power) {
        case Power.discardElement:
          _removeOne(theirWon, (c) => c.element == winCard.element, removed);
        case Power.discardColor:
          _removeOne(theirWon, (c) => c.color == winCard.color, removed);
        case Power.discardAllColor:
          removed.addAll(theirWon.where((c) => c.color == winCard.color));
          theirWon.removeWhere((c) => c.color == winCard.color);
        default:
      }
      if (removed.isNotEmpty) {
        r = RoundResult(r.winner, r.playerElem, r.oppElem, r.playerRank, r.oppRank,
            [...r.powers, winCard.power], removed);
      }
      if (hasWon(myWon)) {
        winner = r.winner;
        finished = true;
      }
    }
    round++;
    _refill();
    if (!finished && (playerHand.isEmpty || oppHand.isEmpty)) finished = true; // empate
    return r;
  }

  void _removeOne(List<CJCard> from, bool Function(CJCard) test, List<CJCard> out) {
    final cands = from.where(test).toList();
    if (cands.isEmpty) return;
    final pick = cands[rng.nextInt(cands.length)];
    from.remove(pick);
    out.add(pick);
  }
}

/// IA sencilla: prefiere rangos altos y cartas que acercan su condición de victoria.
CJCard aiPick(MatchState s, Random rng) {
  CJCard best = s.oppHand.first;
  var bestScore = -1.0;
  for (final c in s.oppHand) {
    var score = c.rank.toDouble() + rng.nextDouble() * 6;
    final sameElem = s.oppWon.where((w) => w.element == c.element);
    if (!sameElem.any((w) => w.color == c.color)) score += 5;
    if (hasWon([...s.oppWon, c])) score += 50;
    if (score > bestScore) { bestScore = score; best = c; }
  }
  return best;
}
