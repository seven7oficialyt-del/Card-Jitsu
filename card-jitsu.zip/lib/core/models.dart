import 'package:flutter/material.dart';

enum Elem { fire, water, snow }
enum CardColor { red, orange, yellow, green, blue, purple }
enum Power { none, plus2, reversal, changeElement, discardElement, discardColor, discardAllColor }
enum Side { player, opp }

extension ElemX on Elem {
  String get icon => 'assets/icons/${name}_icon.png';

  /// Ciclo clásico: fuego > nieve > agua > fuego.
  Elem get beats => switch (this) {
        Elem.fire => Elem.snow,
        Elem.snow => Elem.water,
        Elem.water => Elem.fire,
      };

  /// Elemento al que cambia el poder "cambiar elemento" (fuego→nieve→agua→fuego).
  Elem get converted => beats;

  Color get tint => switch (this) {
        Elem.fire => const Color(0xFFE8531F),
        Elem.water => const Color(0xFF2E8BE6),
        Elem.snow => const Color(0xFF9FD8F5),
      };
}

extension ColorX on CardColor {
  Color get value => switch (this) {
        CardColor.red => const Color(0xFFE63925),
        CardColor.orange => const Color(0xFFFA942A),
        CardColor.yellow => const Color(0xFFFEEB2B),
        CardColor.green => const Color(0xFF3CDC45),
        CardColor.blue => const Color(0xFF0E4C9C),
        CardColor.purple => const Color(0xFFA49AC7),
      };
}

class CJCard {
  final int id;
  final CardColor color;
  final Elem element;
  final int rank;
  const CJCard(this.id, this.color, this.element, this.rank);

  factory CJCard.fromJson(Map<String, dynamic> j) => CJCard(
        j['id'] as int,
        CardColor.values.byName(j['color'] as String),
        Elem.values.byName(j['element'] as String),
        j['rank'] as int,
      );

  String get asset => 'assets/cards/card$id.png';

  /// Mapeo rango → poder (editable aquí; los datos originales estaban compilados).
  Power get power {
    if (rank < 9) return Power.none;
    switch (rank) {
      case 9:
        return Power.plus2;
      case 10:
        return Power.reversal;
      case 11:
        return Power.changeElement;
      default:
        return switch (color) {
          CardColor.red || CardColor.orange => Power.discardElement,
          CardColor.yellow || CardColor.green => Power.discardColor,
          CardColor.blue || CardColor.purple => Power.discardAllColor,
        };
    }
  }

  @override
  bool operator ==(Object o) => o is CJCard && o.id == id;
  @override
  int get hashCode => id;
}
