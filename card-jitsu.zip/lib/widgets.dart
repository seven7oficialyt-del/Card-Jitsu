import 'package:flutter/material.dart';
import 'app_state.dart';
import 'core/models.dart';

/// Imagen de asset con respaldo: si el archivo no existe, no rompe la app.
class AssetImg extends StatelessWidget {
  final String path;
  final BoxFit fit;
  final double? width, height;
  final Widget? fallback;
  const AssetImg(this.path, {super.key, this.fit = BoxFit.contain, this.width, this.height, this.fallback});
  @override
  Widget build(BuildContext context) => Image.asset(path, fit: fit, width: width, height: height,
      errorBuilder: (_, __, ___) => fallback ?? SizedBox(width: width, height: height));
}

class Backdrop extends StatelessWidget {
  final String asset;
  final Widget child;
  const Backdrop({super.key, required this.asset, required this.child});
  @override
  Widget build(BuildContext context) => Stack(fit: StackFit.expand, children: [
        AssetImg(asset, fit: BoxFit.cover,
            fallback: const DecoratedBox(decoration: BoxDecoration(
                gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
                    colors: [Color(0xFF123A66), Color(0xFF0A1B33)])))),
        SafeArea(child: child),
      ]);
}

/// Carta: usa la imagen si existe; si no, dibuja una carta provisional.
class CardView extends StatelessWidget {
  final CJCard? card; // null = reverso
  final double height;
  final VoidCallback? onTap;
  const CardView({super.key, this.card, this.height = 110, this.onTap});

  @override
  Widget build(BuildContext context) {
    final w = height * 164 / 185;
    final c = card;
    final child = c == null
        ? AssetImg('assets/images/card_back.png', width: w, height: height, fallback: _box(Colors.blueGrey, w, const SizedBox()))
        : AssetImg(c.asset, width: w, height: height, fallback: _placeholder(c, w));
    return GestureDetector(onTap: onTap, child: child);
  }

  Widget _box(Color col, double w, Widget inner) => Container(
      width: w, height: height,
      decoration: BoxDecoration(color: col, borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.white54, width: 2)),
      child: inner);

  Widget _placeholder(CJCard c, double w) => _box(c.color.value, w,
      Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        AssetImg(c.element.icon, height: height * .3, fallback: Icon(Icons.circle, color: c.element.tint)),
        Text('${c.rank}', style: TextStyle(fontSize: height * .3, fontWeight: FontWeight.bold, color: Colors.black)),
      ]));
}

class CoinBadge extends StatelessWidget {
  const CoinBadge({super.key});
  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(20)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        const AssetImg('assets/icons/bag_of_coins.png', height: 24, fallback: Icon(Icons.monetization_on, color: Colors.amber)),
        const SizedBox(width: 6),
        Text('${app.coins}', style: const TextStyle(color: Colors.white, fontFamily: 'Salsa', fontSize: 18)),
      ]),
    );
  }
}

class BigButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final double width;
  const BigButton(this.label, {super.key, this.onTap, this.width = 240});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: SizedBox(width: width, height: 48,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1B6FD1), foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24))),
            onPressed: onTap,
            child: Text(label, style: const TextStyle(fontFamily: 'Salsa', fontSize: 20)),
          )),
      );
}

class ScreenBar extends StatelessWidget {
  final String title;
  final bool showCoins;
  const ScreenBar(this.title, {super.key, this.showCoins = true});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(8),
        child: Row(children: [
          IconButton(icon: const Icon(Icons.arrow_back, color: Colors.white), onPressed: () => Navigator.pop(context)),
          Text(title, style: const TextStyle(color: Colors.white, fontFamily: 'Salsa', fontSize: 26)),
          const Spacer(),
          if (showCoins) const CoinBadge(),
        ]),
      );
}
