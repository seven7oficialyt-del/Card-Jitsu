import 'dart:convert';
import 'dart:math';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/models.dart';

const belts = <(String, int)>[
  ('white', 0), ('yellow', 5), ('orange', 15), ('green', 30), ('blue', 50),
  ('purple', 80), ('red', 120), ('brown', 170), ('black', 250),
];
const packPrice = 120;
const packCardsPerElement = 2;
const winCoins = 30, lossCoins = 10;

class AppState extends ChangeNotifier {
  late SharedPreferences _p;
  final _rng = Random();
  final _player = AudioPlayer();
  List<CJCard> allCards = [];
  Map<int, CJCard> _byId = {};
  List<int> collection = []; // ids (puede haber repetidas)
  int coins = 0, wins = 0, losses = 0;
  String lang = 'spanish';
  bool sound = true;
  Map<String, String> _strings = {};

  static const langs = ['spanish', 'english', 'portuguese'];

  Future<void> init() async {
    _p = await SharedPreferences.getInstance();
    final raw = jsonDecode(await rootBundle.loadString('assets/data/cards.json')) as List;
    allCards = raw.map((e) => CJCard.fromJson(e as Map<String, dynamic>)).toList();
    _byId = {for (final c in allCards) c.id: c};
    lang = _p.getString('lang') ?? 'spanish';
    sound = _p.getBool('sound') ?? true;
    coins = _p.getInt('coins') ?? 100;
    wins = _p.getInt('wins') ?? 0;
    losses = _p.getInt('losses') ?? 0;
    final saved = _p.getStringList('collection');
    collection = saved?.map(int.parse).where(_byId.containsKey).toList() ?? _starterCards();
    await _loadLang();
    await _save();
  }

  List<int> _starterCards() => [
        for (final e in Elem.values) ..._draw(e, 5),
      ];

  List<int> _draw(Elem e, int n) {
    final pool = allCards.where((c) => c.element == e).toList();
    return List.generate(n, (_) => pool[_rng.nextInt(pool.length)].id);
  }

  Future<void> _save() async {
    await _p.setString('lang', lang);
    await _p.setBool('sound', sound);
    await _p.setInt('coins', coins);
    await _p.setInt('wins', wins);
    await _p.setInt('losses', losses);
    await _p.setStringList('collection', collection.map((e) => '$e').toList());
  }

  List<CJCard> get ownedCards => collection.map((id) => _byId[id]!).toList();
  Map<CJCard, int> get ownedCounts {
    final m = <CJCard, int>{};
    for (final c in ownedCards) { m[c] = (m[c] ?? 0) + 1; }
    return m;
  }

  // ---- Cinturones ----
  int beltIndexFor(int w) {
    var i = 0;
    for (var k = 0; k < belts.length; k++) { if (w >= belts[k].$2) i = k; }
    return i;
  }
  int get beltIndex => beltIndexFor(wins);
  String get beltName => belts[beltIndex].$1;

  /// Registra el resultado. Devuelve (monedas ganadas, ¿nuevo cinturón?).
  Future<(int, bool)> recordResult({required bool won}) async {
    final before = beltIndex;
    final gain = won ? winCoins : lossCoins;
    coins += gain;
    if (won) { wins++; } else { losses++; }
    await _save();
    notifyListeners();
    return (gain, beltIndex > before);
  }

  // ---- Tienda ----
  Future<List<CJCard>?> buyPack() async {
    if (coins < packPrice) return null;
    coins -= packPrice;
    final ids = [for (final e in Elem.values) ..._draw(e, packCardsPerElement)];
    collection.addAll(ids);
    await _save();
    notifyListeners();
    return ids.map((i) => _byId[i]!).toList();
  }

  // ---- Ajustes ----
  Future<void> setLang(String l) async { lang = l; await _loadLang(); await _save(); notifyListeners(); }
  Future<void> setSound(bool v) async { sound = v; await _save(); notifyListeners(); }
  Future<void> resetProgress() async {
    coins = 100; wins = 0; losses = 0; collection = _starterCards();
    await _save(); notifyListeners();
  }

  Future<void> _loadLang() async {
    final j = jsonDecode(await rootBundle.loadString('assets/lang/$lang.json')) as Map<String, dynamic>;
    _strings = j.map((k, v) => MapEntry(k, '$v'));
  }

  String t(String key, {Map<String, Object> p = const {}}) {
    var s = _strings[key] ?? key;
    final n = p['number'];
    s = s.replaceAll('{s}', (n is int && n == 1) ? '' : 's');
    p.forEach((k, v) => s = s.replaceAll('{$k}', '$v'));
    return s;
  }

  Future<void> sfx(String file) async {
    if (!sound) return;
    try { await _player.stop(); await _player.play(AssetSource('audio/normal_cj/$file')); } catch (_) {}
  }
}

class AppScope extends InheritedNotifier<AppState> {
  const AppScope({super.key, required AppState state, required super.child}) : super(notifier: state);
  static AppState of(BuildContext c) => c.dependOnInheritedWidgetOfExactType<AppScope>()!.notifier!;
}
