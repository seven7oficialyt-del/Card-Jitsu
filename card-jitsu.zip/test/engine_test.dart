import 'dart:math';
import 'package:card_jitsu/core/engine.dart';
import 'package:card_jitsu/core/models.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  CJCard c(int id, CardColor col, Elem e, int r) => CJCard(id, col, e, r);
  final m = MatchState(Random(1), [], []);

  test('fuego gana a nieve, nieve a agua, agua a fuego', () {
    expect(m.resolve(c(1, CardColor.red, Elem.fire, 2), c(2, CardColor.red, Elem.snow, 12)).winner, Side.player);
    expect(m.resolve(c(1, CardColor.red, Elem.snow, 2), c(2, CardColor.red, Elem.water, 3)).winner, Side.player);
    expect(m.resolve(c(1, CardColor.red, Elem.water, 2), c(2, CardColor.red, Elem.fire, 3)).winner, Side.player);
  });
  test('mismo elemento: mayor rango; empate sin ganador', () {
    expect(m.resolve(c(1, CardColor.red, Elem.fire, 5), c(2, CardColor.blue, Elem.fire, 4)).winner, Side.player);
    expect(m.resolve(c(1, CardColor.red, Elem.fire, 4), c(2, CardColor.blue, Elem.fire, 4)).winner, isNull);
  });
  test('rango 10 invierte: gana el menor', () {
    expect(m.resolve(c(1, CardColor.red, Elem.fire, 10), c(2, CardColor.blue, Elem.fire, 4)).winner, Side.opp);
  });
  test('rango 9 suma 2', () {
    expect(m.resolve(c(1, CardColor.red, Elem.fire, 9), c(2, CardColor.blue, Elem.fire, 8)).playerRank, 11);
  });
  test('victoria: 3 colores del mismo elemento y 3 elementos/colores distintos', () {
    expect(hasWon([c(1, CardColor.red, Elem.fire, 2), c(2, CardColor.blue, Elem.fire, 2), c(3, CardColor.green, Elem.fire, 2)]), isTrue);
    expect(hasWon([c(1, CardColor.red, Elem.fire, 2), c(2, CardColor.blue, Elem.water, 2), c(3, CardColor.green, Elem.snow, 2)]), isTrue);
    expect(hasWon([c(1, CardColor.red, Elem.fire, 2), c(2, CardColor.red, Elem.water, 2), c(3, CardColor.green, Elem.snow, 2)]), isFalse);
  });
}
