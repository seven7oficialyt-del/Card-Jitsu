# Card-Jitsu (clásico) – reconstrucción limpia

Solo modo clásico: menú, partida contra IA, colección, tienda de paquetes, monedas, cinturones, ajustes (3 idiomas).

## Ejecutar
```
flutter pub get
flutter test          # reglas del motor
flutter run
```

## Dónde tocar
- `lib/core/models.dart` → mapeo rango→poder (`CJCard.power`).
- `lib/core/engine.dart` → reglas, victoria, IA.
- `lib/app_state.dart` → precios, monedas por partida, cinturones.
- `assets/data/cards.json` → datos de las cartas (id, color, elemento, rango).
- `assets/data/cards_to_review.json` → cartas cuyo rango no se detectó bien: corrige el rango y pásalas a cards.json.

## Sacar el APK sin PC (GitHub)
1. Crea un repositorio en github.com y sube **card-jitsu.zip** a la raíz (sin descomprimir).
2. Crea el archivo `.github/workflows/build-apk.yml` con el contenido de `build-apk.yml`.
3. Pestaña **Actions** → **Build Card-Jitsu APK** → espera 5-10 min → descarga **Card-Jitsu-APK**.

Con PC: `flutter create --platforms=android --org com.minos .`, copia `android_overrides/res/*` a `android/app/src/main/res/` y `flutter build apk --release`.

Card-Jitsu · Mino's
